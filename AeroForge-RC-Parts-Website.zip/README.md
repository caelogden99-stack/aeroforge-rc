# AeroForge RC Parts Website

This is a simple static website for AeroForge RC, focused on selling 3D-printed RC aircraft parts.

## Files
- index.html — website content
- style.css — styling

## Important
The product prices and email address are placeholders. Replace them with your real information before publishing.

## Publishing
You can upload these files to GitHub Pages, another static host, or use the code as the basis for your Manus site.
